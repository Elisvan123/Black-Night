# `💫 𝑆𝐼𝑀𝑃𝐿𝐸 - 𝐵𝑂𝑇 💫`

### `—◉ 👑 DUDAS SOBRE EL BOT?, CONTACTAME 👑`
<a href="http://wa.me/5219992095479" target="blank"><img src="https://img.shields.io/badge/BRUNO_SOBRINO-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" /></a>
> NO BOT

### `—◉ 💰 DONAR 💰`
- AGRADECE CON UNA DONACION VOLUNTARIA [Aqui](https://www.paypal.me/TheShadowBrokers133)

### `—◉ ⚙️ AJUSTES ⚙️`
- CLONAR EL REPOSITORIO [Aqui](https://github.com/BrunoSobrino/SimpleBot/fork)
- CAMBIAR NÚMERO DEL OWNER [Aqui](https://github.com/BrunoSobrino/SimpleBot/blob/master/config.js)

### `—◉ 💥 ACTIVAR EN ACIDICNODES 💥`
<a href="https://billing.acidicnodes.com"><img src="https://billing.acidicnodes.ml/storage/icon.png" width="200" height="200" alt="AcidicNodes"/></a>
- TUTORIAL: [https://youtu.be/nbjvreJ0tUk](https://youtu.be/nbjvreJ0tUk)
- PAGINA: [https://billing.acidicnodes.com](https://billing.acidicnodes.com)
- SOPORTE: [https://whatsapp.acidicnodes.com](https://whatsapp.acidicnodes.com)

### `—◉ ✨ ACTIVAR EN HEROKU ✨`
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/BrunoSobrino/SimpleBot)
```bash
AÑADE AL APARTADO DE BUILPACK LO SIGUIENTE, SI YA APARCEN SOLO IGNORA ESTA PARTE:
> heroku/nodejs
> https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest
> https://github.com/bogini/heroku-buildpack-graphicsmagick
```

### `—◉ 👾 ACTIVAR EN TERMUX 👾`
```bash
ESCRIBE LOS SIGUIENTES COMANDOS UNO POR UNO:
> cd
> termux-setup-storage
> apt update 
> apt upgrade 
> apt install yarn 
> apt install git -y
> apt install nodejs -y
> apt install ffmpeg -y
> apt install imagemagick -y
> git clone https://github.com/BrunoSobrino/SimpleBot
> cd SimpleBot
> yarn install
> npm install
> npm update
> npm install
> npm start
```

### `—◉ ✔️ ACTIVAR EN CASO DE DETENERSE ✔️`
```bash
ESCRIBE LOS SIGUIENTES COMANDOS UNO POR UNO:
> cd 
> cd SimpleBot
> npm start
```

### `—◉ 👽 OBTENER OTRO CODIGO QR 👽`
```bash
ESCRIBE LOS SIGUIENTES COMANDOS UNO POR UNO:
> cd 
> cd SimpleBot
> rm -rf session.data.json
> npm start
```

## `EDITOR Y PORPIETARIO DEL BOT` 
<a href="https://github.com/BrunoSobrino"><img src="https://github.com/BrunoSobrino.png" width="300" height="300" alt="BrunoSobrino"/></a>

`TheMystic-Bot-MD _ By Bruno Sobrino`
